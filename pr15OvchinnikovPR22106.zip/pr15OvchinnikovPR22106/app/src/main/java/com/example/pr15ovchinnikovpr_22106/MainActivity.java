package com.example.pr15ovchinnikovpr_22106;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import kotlin.jvm.internal.Ref;

public class MainActivity extends AppCompatActivity{

    Button save, load;
    EditText input;
    TextView outText;
    String temp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        save = findViewById(R.id.button);
        load = findViewById(R.id.button2);
        input = findViewById(R.id.editTextTextPersonName);
        outText = findViewById(R.id.textView2);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                temp = input.getText().toString();
                input.setText("");
            }
        });
        load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                outText.setText(temp);
            }
        });
    }
}

